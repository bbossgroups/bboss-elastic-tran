本地日志文件和ftp日志文件采集插件，使用参考文档：

https://esdoc.bbossgroups.com/#/filelog-guide

子目录文件采集和备份、删除处理