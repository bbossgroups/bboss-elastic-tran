https://github.com/phutchins/logstash-input-mongodb/blob/master/lib/logstash/inputs/mongodb.rb
https://www.cnblogs.com/mottled/p/8317810.html